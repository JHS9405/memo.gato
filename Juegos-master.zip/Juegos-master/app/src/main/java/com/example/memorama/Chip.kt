package com.example.memorama

data class Chip(val idImage: Int,val pos:Int,val id:String)